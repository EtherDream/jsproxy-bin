该目录存放 HTTPS 证书，每个域名使用独立的目录。

证书通过 `~/server/gen-cert/gen.sh` 生成。