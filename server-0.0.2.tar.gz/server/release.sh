git archive --format=tar.gz --prefix=server/ dev > ../bin/server-0.0.2.tar.gz
